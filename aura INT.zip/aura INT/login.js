document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Simple validation (can be enhanced)
    if (username && email && password) {
        document.getElementById('message').innerText = "Registration successful!";
        // Here you can also add logic to send the data to a server
    } else {
        document.getElementById('message').innerText = "Please fill out all fields.";
    }
});
