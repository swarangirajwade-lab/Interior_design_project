<?php
// Database configuration
$servername = "localhost";  // Change this if needed
$username = "root";         // Your MySQL username
$password = "";             // Your MySQL password
$dbname = "user_registration";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for a connection error
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $user = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm-password']);
    
    // Check if passwords match
    if ($password != $confirm_password) {
        $message = "Passwords do not match!";
    } else {
        // Hash the password before storing it in the database
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Check if the username or email already exists
        $sql_check = "SELECT * FROM users WHERE username='$user' OR email='$email'";
        $result = $conn->query($sql_check);
        
        if ($result->num_rows > 0) {
            $message = "Username or Email already taken!";
        } else {
            // Insert data into the users table
            $sql = "INSERT INTO users (username, email, password) VALUES ('$user', '$email', '$hashed_password')";
            
            if ($conn->query($sql) === TRUE) {
                $message = "Registration successful!";
            } else {
                $message = "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <title>Sign Up</title>
</head>
<body background="bg.jpg">
    <div class="container">
        <h1>Sign Up</h1>
        <form id="signupForm" method="POST" action="">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="confirm-password">Confirm Password:</label>
                <input type="password" id="confirm-password" name="confirm-password" required>
            </div>
            <!-- Update to prevent default submission -->
            <button type="submit" onclick="submitForm(event)">Sign Up</button>
        </form>
        
        <?php if (!empty($message)) { ?>
            <div id="message">
                <p><?php echo $message; ?></p>
            </div>
        <?php } ?>
    </div>

    <script>
        // This function prevents the default form submission and redirects after form submission
        function submitForm(event) {
            // Prevent the default form submission
            event.preventDefault();

            // Submit the form using JavaScript
            document.getElementById('signupForm').submit();

            // Redirect to the index page after the form is submitted
            window.location.href = 'file:///C:/xampp/htdocs/aura%20int/index.html'; // Change to your desired page
        }
    </script>
</body>
</html>
